<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '[u0)Y#$*-|eHqq0,[=ak%f+i%|q[4sr2%sy,M.hVtEpN|a,BU,Xy&*8x5u/sQ;<{' );
define( 'SECURE_AUTH_KEY',  '9ViCyVE5at4G>c*7/F68LT6r wN6+$}NcHQ[r1-m&5d w1&s2(WV_kb_N=YOmu-R' );
define( 'LOGGED_IN_KEY',    'p:zz(.%m1czZ wsa~1ZxF-4KwRr)YAoXP~~8TIj.ae>jz6])ld9ch~]6}zEf^5nJ' );
define( 'NONCE_KEY',        'hld{s=(YMlz3[Jq.%UNCC`f=ApBwSMAt)ui2DC6t,:fj[GON:q]L<L92V.a<32Ag' );
define( 'AUTH_SALT',        '/lq|i(qQzyogR+7CQa[?{fbXco%U2kisnPH5LK-WIP&TtR8`IdkV:/@#b*fD{o<;' );
define( 'SECURE_AUTH_SALT', 'mn{[]%ZYJOq;ZBO.tJ#.[lt1-$mc/le#q#H,j&x>U,?OToi:;&kYJj<+nWk$j^V ' );
define( 'LOGGED_IN_SALT',   '{e;kzJY5i8kqcj{Ed$$p>$|YO&X88~_txb%pOcpDIR;@pj%z{VoM:zT2cVA4I=,H' );
define( 'NONCE_SALT',       'qk3`6&zLH>elMm++y1Vvg)_MTd^}ayk=nv{^m5QEosJR^Ew_%PfX.{ec&W>X-n M' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
